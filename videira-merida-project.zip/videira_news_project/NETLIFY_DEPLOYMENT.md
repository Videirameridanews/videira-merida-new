# Guía de Deployment en Netlify - Videira Mérida

## 📋 Requisitos Previos

Antes de comenzar, asegúrate de tener:

- Una cuenta en [Netlify](https://netlify.com) (puedes crear una gratis)
- Tu repositorio en [GitHub](https://github.com), [GitLab](https://gitlab.com) o [Bitbucket](https://bitbucket.org)
- Git instalado en tu computadora

## 🚀 Opción 1: Deployment Automático (Recomendado)

Esta opción conecta tu repositorio a Netlify para que se actualice automáticamente cada vez que hagas push a tu rama principal.

### Paso 1: Preparar tu Repositorio

1. Inicializa Git en tu proyecto (si no lo has hecho):
```bash
cd videira_news_project
git init
git add .
git commit -m "Initial commit: Videira Mérida website"
```

2. Crea un repositorio en GitHub:
   - Ve a [github.com/new](https://github.com/new)
   - Nombre: `videira-merida-news`
   - Descripción: "Sitio web de Videira Mérida"
   - Privado o Público (tu elección)
   - Clic en "Create repository"

3. Conecta tu repositorio local a GitHub:
```bash
git remote add origin https://github.com/TU_USUARIO/videira-merida-news.git
git branch -M main
git push -u origin main
```

### Paso 2: Conectar a Netlify

1. Ve a [app.netlify.com](https://app.netlify.com)
2. Inicia sesión con tu cuenta de Netlify
3. Haz clic en **"Add new site"** → **"Import an existing project"**
4. Selecciona tu proveedor de Git (GitHub, GitLab, o Bitbucket)
5. Autoriza a Netlify para acceder a tus repositorios
6. Selecciona el repositorio `videira-merida-news`
7. Configura el build:
   - **Branch to deploy**: `main`
   - **Build command**: `npm run build`
   - **Publish directory**: `dist/public`
8. Haz clic en **"Deploy site"**

Netlify comenzará a construir tu sitio automáticamente. ¡Espera a que termine!

## 🔧 Opción 2: Deployment Manual (CLI)

Si prefieres desplegar manualmente sin conectar un repositorio:

### Paso 1: Instalar Netlify CLI

```bash
npm install -g netlify-cli
```

### Paso 2: Construir tu Sitio

```bash
cd videira_news_project
npm run build
```

### Paso 3: Desplegar a Netlify

```bash
netlify deploy --prod --dir=dist/public
```

Sigue las instrucciones en la terminal:
- Si es tu primer deploy, selecciona "Create & configure a new site"
- Elige tu equipo (o crea uno nuevo)
- Asigna un nombre a tu sitio (ej: `videira-merida`)
- Confirma el directorio a desplegar: `dist/public`

## 📝 Configuración de Dominio Personalizado

Una vez que tu sitio esté en Netlify:

1. Ve a **Site settings** → **Domain management**
2. Haz clic en **"Add custom domain"**
3. Ingresa tu dominio (ej: `videiramerida.com`)
4. Sigue las instrucciones para actualizar los registros DNS en tu proveedor de dominio

## 🔄 Actualizaciones Futuras

### Si usas Deployment Automático:
Simplemente haz push a tu rama `main`:
```bash
git add .
git commit -m "Descripción de cambios"
git push origin main
```

Netlify detectará los cambios automáticamente y desplegará la nueva versión.

### Si usas Deployment Manual:
Repite el proceso:
```bash
npm run build
netlify deploy --prod --dir=dist/public
```

## 🛡️ Variables de Entorno

Si necesitas variables de entorno en Netlify:

1. Ve a **Site settings** → **Build & deploy** → **Environment**
2. Haz clic en **"Edit variables"**
3. Añade tus variables (las mismas que en tu `.env.local`)

## ✅ Verificación Post-Deployment

Después de desplegar, verifica que todo funcione correctamente:

- [ ] El sitio carga correctamente
- [ ] La navegación entre páginas funciona (Home, Sobre Nosotros, Contacto)
- [ ] El formulario de contacto abre correctamente
- [ ] Las imágenes se cargan sin problemas
- [ ] El sitio es responsive en móvil
- [ ] Las animaciones funcionan suavemente

## 🐛 Solución de Problemas

### El sitio muestra error 404 en rutas internas

**Solución**: Asegúrate de que el archivo `netlify.toml` esté en la raíz del proyecto con la configuración correcta de redirects.

### Las imágenes no se cargan

**Solución**: Verifica que las URLs de las imágenes en CDN sean correctas y accesibles públicamente.

### El build falla en Netlify

**Solución**:
1. Revisa los logs de build en Netlify (Site → Deploys → último deploy → Build log)
2. Asegúrate de que `npm run build` funciona localmente
3. Verifica que todas las dependencias estén en `package.json`

### El formulario no envía emails

**Solución**: El formulario actual es un placeholder. Necesitas:
1. Configurar un servicio como Formspree, SendGrid o tu propio backend
2. Actualizar la URL del endpoint en `ContactFormModal.tsx`

## 📚 Recursos Útiles

- [Documentación de Netlify](https://docs.netlify.com/)
- [Guía de Vite para Netlify](https://vitejs.dev/guide/static-deploy.html#netlify)
- [Netlify CLI Docs](https://cli.netlify.com/)

## 💡 Consejos Finales

- **Backups**: Siempre mantén tu código en Git
- **Monitoreo**: Usa Netlify Analytics para ver el tráfico de tu sitio
- **Certificado SSL**: Netlify proporciona certificados SSL gratis automáticamente
- **CDN**: Netlify distribuye tu sitio globalmente a través de su CDN

¡Tu sitio de Videira Mérida está listo para el mundo! 🌍
