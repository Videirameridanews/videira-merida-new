import { Mail, MapPin, Instagram, Facebook, Clock, Phone } from 'lucide-react';
import { useLocation } from 'wouter';
import { useState } from 'react';
import ContactFormModal from '@/components/ContactFormModal';

export default function Contact() {
  const [, navigate] = useLocation();
  const logoUrl = "https://d2xsxph8kpxj0f.cloudfront.net/310419663031399969/6U8riXrUQz35LRU9RLXBMZ/64405_9ce182b7.png";
  const [isFormOpen, setIsFormOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white py-8 px-4 sticky top-0 z-50 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <img 
              src={logoUrl} 
              alt="Videira Logo" 
              className="h-16 w-16 object-contain"
            />
            <div>
              <h1 className="text-3xl font-bold">Videira</h1>
              <p className="text-sm text-cyan-300">Mérida</p>
            </div>
          </button>
          <nav className="flex gap-6">
            <button
              onClick={() => navigate('/')}
              className="text-cyan-300 hover:text-cyan-100 transition-colors font-medium"
            >
              Inicio
            </button>
            <button
              onClick={() => navigate('/about')}
              className="text-cyan-300 hover:text-cyan-100 transition-colors font-medium"
            >
              Sobre Nosotros
            </button>
            <button
              onClick={() => navigate('/contact')}
              className="text-yellow-400 font-medium"
            >
              Contacto
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <section className="mb-16 text-center">
          <h1 className="text-5xl font-bold text-slate-900 mb-6">Contáctanos</h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Nos encantaría escucharte. Ponte en contacto con nosotros para cualquier pregunta, comentario o si deseas visitarnos.
          </p>
        </section>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Contact Information */}
          <section className="space-y-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-8">Información de Contacto</h2>

            <div className="flex gap-4">
              <MapPin className="text-cyan-600 flex-shrink-0 mt-1" size={28} />
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Dirección</h3>
                <p className="text-gray-700">Calle 4 Diagonal 151</p>
                <p className="text-gray-700">Residencial Montecristo</p>
                <p className="text-gray-700">Mérida, México</p>
              </div>
            </div>

            <div className="flex gap-4">
              <Clock className="text-purple-600 flex-shrink-0 mt-1" size={28} />
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Horario de Reunión</h3>
                <p className="text-gray-700">Domingos</p>
                <p className="text-gray-700 font-semibold text-lg">12:00 PM</p>
              </div>
            </div>

            <div className="flex gap-4">
              <Mail className="text-yellow-600 flex-shrink-0 mt-1" size={28} />
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Correo Electrónico</h3>
                <p className="text-gray-700">info@videiramerida.com</p>
              </div>
            </div>

            <div className="flex gap-4">
              <Phone className="text-cyan-500 flex-shrink-0 mt-1" size={28} />
              <div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Teléfono</h3>
                <p className="text-gray-700">+52 (999) XXX-XXXX</p>
              </div>
            </div>

            {/* Social Media */}
            <div>
              <h3 className="text-xl font-bold text-slate-900 mb-4">Síguenos en Redes Sociales</h3>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 transition-colors"
                  title="Facebook"
                >
                  <Facebook size={24} />
                </a>
                <a
                  href="#"
                  className="bg-pink-600 text-white p-3 rounded-full hover:bg-pink-700 transition-colors"
                  title="Instagram"
                >
                  <Instagram size={24} />
                </a>
              </div>
            </div>
          </section>

          {/* Contact Form Button */}
          <section>
            <h2 className="text-3xl font-bold text-slate-900 mb-8">Envíanos un Mensaje</h2>
            <button
              onClick={() => setIsFormOpen(true)}
              className="w-full bg-gradient-to-r from-cyan-600 to-purple-600 text-white font-bold py-4 rounded-lg hover:from-cyan-700 hover:to-purple-700 transition-colors shadow-md text-lg"
            >
              Abrir Formulario de Contacto
            </button>
          </section>
        </div>

        {/* Map Section (Placeholder) */}
        <section className="bg-gray-100 rounded-lg p-8 text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Ubicación</h2>
          <div className="bg-gray-300 rounded-lg h-96 flex items-center justify-center">
            <p className="text-gray-700 text-lg">
              Mapa interactivo - Calle 4 Diagonal 151, Residencial Montecristo
            </p>
          </div>
        </section>

        {/* Call to Action */}
        <section className="bg-gradient-to-r from-cyan-600 to-purple-600 text-white rounded-lg p-8 text-center shadow-lg">
          <h2 className="text-3xl font-bold mb-4">¿Tienes Preguntas?</h2>
          <p className="text-lg mb-6">
            No dudes en contactarnos. Estamos aquí para ayudarte y responder cualquier pregunta que tengas.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="bg-yellow-400 text-slate-900 px-8 py-3 rounded-lg font-bold hover:bg-yellow-300 transition-colors shadow-md"
          >
            Contáctanos
          </button>
        </section>

        {/* Contact Form Modal */}
        <ContactFormModal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} />
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-8 px-4 mt-16">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-gray-400">
            © 2026 Videira Mérida. Todos los derechos reservados.
          </p>
          <p className="text-xs text-gray-500 mt-2">
            "Ciertamente que la bondad y la misericordia me seguirán todos los días de mi vida; y habitaré en la Casa del Señor para todo el siempre." (Salmo 23:6)
          </p>
        </div>
      </footer>
    </div>
  );
}
