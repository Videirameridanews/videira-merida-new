import { Heart, Users, Lightbulb, Target } from 'lucide-react';
import { useLocation } from 'wouter';

export default function About() {
  const [, navigate] = useLocation();
  const logoUrl = "https://d2xsxph8kpxj0f.cloudfront.net/310419663031399969/6U8riXrUQz35LRU9RLXBMZ/64405_9ce182b7.png";

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white py-8 px-4 sticky top-0 z-50 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <img 
              src={logoUrl} 
              alt="Videira Logo" 
              className="h-16 w-16 object-contain"
            />
            <div>
              <h1 className="text-3xl font-bold">Videira</h1>
              <p className="text-sm text-cyan-300">Mérida</p>
            </div>
          </button>
          <nav className="flex gap-6">
            <button
              onClick={() => navigate('/')}
              className="text-cyan-300 hover:text-cyan-100 transition-colors font-medium"
            >
              Inicio
            </button>
            <button
              onClick={() => navigate('/about')}
              className="text-yellow-400 font-medium"
            >
              Sobre Nosotros
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <section className="mb-16 text-center">
          <h1 className="text-5xl font-bold text-slate-900 mb-6">Sobre Videira Mérida</h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Somos una comunidad de fe dedicada a vivir la palabra de Dios con sinceridad, propósito y amor incondicional.
          </p>
        </section>

        {/* Mission, Vision, Values */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {/* Mission */}
          <div className="bg-gradient-to-br from-cyan-50 to-cyan-100 rounded-lg p-8 shadow-md hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-3 mb-4">
              <Target className="text-cyan-600" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Misión</h3>
            </div>
            <p className="text-gray-700">
              Proclamar el evangelio de Jesucristo y ayudar a las personas a desarrollar una relación profunda con Dios, transformando vidas a través de la fe y el amor.
            </p>
          </div>

          {/* Vision */}
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-8 shadow-md hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-3 mb-4">
              <Lightbulb className="text-purple-600" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Visión</h3>
            </div>
            <p className="text-gray-700">
              Ser una iglesia que refleja la sincronía perfecta de Dios, donde cada miembro experimenta su poder transformador y se convierte en un instrumento de bendición para la comunidad.
            </p>
          </div>

          {/* Values */}
          <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-8 shadow-md hover:shadow-lg transition-shadow">
            <div className="flex items-center gap-3 mb-4">
              <Heart className="text-yellow-600" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Valores</h3>
            </div>
            <p className="text-gray-700">
              Fe, amor, sinceridad, comunidad, crecimiento espiritual y servicio desinteresado. Creemos en el poder transformador de la palabra de Dios.
            </p>
          </div>
        </section>

        {/* Our Community */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-8 text-center">Nuestra Comunidad</h2>
          <div className="bg-gradient-to-r from-cyan-600 to-purple-600 text-white rounded-lg p-12 shadow-lg">
            <div className="flex items-center gap-4 mb-6">
              <Users size={40} />
              <h3 className="text-3xl font-bold">Somos Familia</h3>
            </div>
            <p className="text-lg leading-relaxed mb-6">
              En Videira Mérida, no somos solo una congregación, somos una familia. Nos reunimos cada domingo a las 12:00 PM para adorar, crecer espiritualmente y apoyarnos mutuamente en nuestro caminar con Cristo. Aquí encontrarás un lugar donde eres aceptado tal como eres, donde tus luchas son nuestras luchas y tus alegrías son nuestras alegrías.
            </p>
            <p className="text-lg">
              Creemos que Dios tiene un plan perfecto para cada uno de nosotros, y estamos comprometidos a ayudarte a descubrir la sincronía divina en tu vida.
            </p>
          </div>
        </section>

        {/* What We Offer */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-8 text-center">Lo Que Ofrecemos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="border-l-4 border-cyan-600 pl-6 py-4">
              <h3 className="text-2xl font-bold text-slate-900 mb-3">Cultos Dominicales</h3>
              <p className="text-gray-700">
                Cada domingo a las 12:00 PM nos reunimos para adorar, escuchar la palabra de Dios y fortalecer nuestra fe en comunidad.
              </p>
            </div>

            <div className="border-l-4 border-purple-600 pl-6 py-4">
              <h3 className="text-2xl font-bold text-slate-900 mb-3">Grupos de Oración</h3>
              <p className="text-gray-700">
                Espacios íntimos donde compartimos nuestras necesidades y oramos juntos, experimentando el poder transformador de la intercesión.
              </p>
            </div>

            <div className="border-l-4 border-yellow-600 pl-6 py-4">
              <h3 className="text-2xl font-bold text-slate-900 mb-3">Estudio Bíblico</h3>
              <p className="text-gray-700">
                Profundizamos en la palabra de Dios a través de estudios estructurados que nos ayudan a entender mejor su propósito para nuestras vidas.
              </p>
            </div>

            <div className="border-l-4 border-cyan-500 pl-6 py-4">
              <h3 className="text-2xl font-bold text-slate-900 mb-3">Ministerio Comunitario</h3>
              <p className="text-gray-700">
                Nos comprometemos a servir a nuestra comunidad, llevando esperanza y bendición a quienes más lo necesitan.
              </p>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="bg-gradient-to-r from-cyan-600 to-purple-600 text-white rounded-lg p-8 text-center shadow-lg">
          <h2 className="text-3xl font-bold mb-4">¿Listo para Unirte?</h2>
          <p className="text-lg mb-6">
            Te invitamos a ser parte de Videira Mérida. Ven tal como eres y descubre la sincronía perfecta de Dios en tu vida.
          </p>
          <button className="bg-yellow-400 text-slate-900 px-8 py-3 rounded-lg font-bold hover:bg-yellow-300 transition-colors shadow-md">
            Contáctanos
          </button>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-8 px-4 mt-16">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-gray-400">
            © 2026 Videira Mérida. Todos los derechos reservados.
          </p>
          <p className="text-xs text-gray-500 mt-2">
            "Ciertamente que la bondad y la misericordia me seguirán todos los días de mi vida; y habitaré en la Casa del Señor para todo el siempre." (Salmo 23:6)
          </p>
        </div>
      </footer>
    </div>
  );
}
