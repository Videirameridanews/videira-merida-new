import { Mail, MapPin, Instagram, Facebook, Clock, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import ContactFormModal from '@/components/ContactFormModal';

export default function Home() {
  const imageUrl = "https://d2xsxph8kpxj0f.cloudfront.net/310419663031399969/6U8riXrUQz35LRU9RLXBMZ/palabra_semana_imagen_61a89be8.png";
  const logoUrl = "https://d2xsxph8kpxj0f.cloudfront.net/310419663031399969/6U8riXrUQz35LRU9RLXBMZ/64405_9ce182b7.png";
  
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Header Section */}
      <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white py-8 px-4 sticky top-0 z-50 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            {/* Logo */}
            <div className="flex items-center gap-4">
              <img 
                src={logoUrl} 
                alt="Videira Logo" 
                className="h-20 w-20 object-contain drop-shadow-lg hover:scale-110 transition-transform duration-300"
              />
              <div>
                <h1 className="text-4xl font-bold tracking-tight">Videira</h1>
                <p className="text-sm text-cyan-300">Mérida</p>
              </div>
            </div>

            {/* News Section */}
            <div className="text-right">
              <p className="text-3xl font-light text-cyan-400">NEWS</p>
              <p className="text-sm text-cyan-300 font-light">8 / marzo / 2026</p>
            </div>
          </div>

          {/* Schedule Banner */}
          <div className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg inline-flex items-center gap-2 font-bold">
            <Clock size={20} />
            <span>Domingos 12:00 PM</span>
          </div>
        </div>
      </header>

      {/* Social Media Bar */}
      <div className="bg-gradient-to-r from-purple-600 via-cyan-500 to-cyan-600 text-white py-4 px-4">
        <div className="max-w-6xl mx-auto flex items-center justify-center gap-8">
          <a href="#" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <Facebook size={24} />
            <span className="text-sm font-medium">Videira_merida</span>
          </a>
          <a href="#" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <Instagram size={24} />
            <span className="text-sm font-medium">Videira_merida</span>
          </a>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-12">
        {/* Word of the Week Section */}
        <section className="mb-16">
          {/* Section Title */}
          <div className="mb-8 animate-fade-in">
            <div className="inline-block bg-yellow-400 text-slate-900 px-8 py-3 rounded-full font-bold text-2xl shadow-lg hover:shadow-xl transition-shadow">
              PALABRA DE LA SEMANA
            </div>
          </div>

          {/* Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Image */}
            <div className="lg:col-span-1">
              <img
                src={imageUrl}
                alt="La Sincronía de Dios"
                className="w-full h-auto rounded-lg shadow-lg object-cover hover:shadow-2xl transition-shadow duration-300"
              />
            </div>

            {/* Text Content */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h2 className="text-3xl font-bold text-slate-900 mb-2">
                  La Sincronía de Dios
                </h2>
                <p className="text-sm text-gray-600 font-medium">Por: Xavi Alonzo</p>
              </div>

              <p className="text-gray-700 leading-relaxed">
                ¿Alguna vez te has sorprendido por la precisión con la que Dios actúa en nuestras vidas? A menudo, nos desesperamos en la "bendita espera", sintiendo que el tiempo se nos escapa entre los dedos. Sin embargo, nuestro Dios es un experto en romper los paradigmas del tiempo y el caos, transformando tragedias en lechos de flores.
              </p>

              <p className="text-gray-700 leading-relaxed">
                La Biblia nos relata historias fascinantes sobre esta sincronía divina. Recordemos a la mujer sunamita (2 Reyes 8:1-6), quien tras siete años de ausencia, regresó para pedir al rey sus tierras. Justo en ese preciso instante, Giezi le contaba al rey cómo Eliseo había resucitado al hijo de esta mujer. ¡Solo Dios puede orquestar un encuentro tan perfecto! No fue casualidad; fue la sincronía de Su control absoluto.
              </p>

              <p className="text-gray-700 leading-relaxed">
                Otro ejemplo conmovedor es el de Jairo (Marcos 5:21-43). Mientras él corría desesperado porque su hija moría, Jesús se detuvo a sanar a una mujer que tocó su manto. Para Jairo, el tiempo se agotaba; para Dios, el tiempo apenas comenzaba. Aunque las noticias decían "ya no molestes al Maestro", Jesús simplemente susurró: "Solo duerme". En el momento exacto, la niña despertó.
              </p>

              <p className="text-gray-700 leading-relaxed">
                Hoy, Dios quiere recordarte que tu obediencia será probada, pero también será recompensada. El tiempo de la vergüenza está llegando a su fin. Todo lo que perdiste durante años será restituido, porque el Señor siempre tiene tiempo para actuar y Su sincronía es única.
              </p>

              {/* Bible Quote */}
              <div className="border-l-4 border-yellow-400 pl-6 py-4 bg-gray-50 rounded hover:bg-yellow-50 transition-colors">
                <p className="text-gray-700 italic font-medium">
                  "SEÑOR, es tiempo de que actúes, porque esta gente malvada ha desobedecido tus enseñanzas."
                </p>
                <p className="text-sm text-gray-600 mt-2">(Salmos 119:126 NTV)</p>
              </div>
            </div>
          </div>
        </section>

        {/* Divider */}
        <hr className="my-12 border-gray-300" />

        {/* Expandable Sections */}
        <section className="space-y-6 mb-12">
          {/* About Section */}
          <div className="border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
            <button
              onClick={() => toggleSection('about')}
              className="w-full bg-gradient-to-r from-cyan-600 to-cyan-500 text-white px-6 py-4 flex items-center justify-between hover:from-cyan-700 hover:to-cyan-600 transition-colors"
            >
              <h3 className="text-xl font-bold">Sobre Videira Mérida</h3>
              <ChevronDown
                size={24}
                className={`transition-transform duration-300 ${
                  expandedSection === 'about' ? 'rotate-180' : ''
                }`}
              />
            </button>
            {expandedSection === 'about' && (
              <div className="px-6 py-6 bg-white space-y-4">
                <p className="text-gray-700 leading-relaxed">
                  Somos una comunidad de fe dedicada a vivir la palabra de Dios con sinceridad y propósito. En Videira Mérida, creemos que Dios tiene un plan perfecto para cada uno de nosotros, y nos reunimos cada semana para adorar, crecer espiritualmente y apoyarnos mutuamente en nuestro caminar con Cristo.
                </p>
              </div>
            )}
          </div>

          {/* Location & Contact Section */}
          <div className="border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
            <button
              onClick={() => toggleSection('contact')}
              className="w-full bg-gradient-to-r from-purple-600 to-purple-500 text-white px-6 py-4 flex items-center justify-between hover:from-purple-700 hover:to-purple-600 transition-colors"
            >
              <h3 className="text-xl font-bold">Ubicación y Contacto</h3>
              <ChevronDown
                size={24}
                className={`transition-transform duration-300 ${
                  expandedSection === 'contact' ? 'rotate-180' : ''
                }`}
              />
            </button>
            {expandedSection === 'contact' && (
              <div className="px-6 py-6 bg-white space-y-6">
                <div className="flex gap-4">
                  <MapPin className="text-cyan-600 flex-shrink-0 mt-1" size={24} />
                  <div>
                    <p className="font-semibold text-gray-900">Dirección</p>
                    <p className="text-gray-700">Calle 4 Diagonal 151</p>
                    <p className="text-gray-700">Residencial Montecristo</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Instagram className="text-cyan-600 flex-shrink-0 mt-1" size={24} />
                  <div>
                    <p className="font-semibold text-gray-900">Instagram</p>
                    <p className="text-gray-700">@Videira_merida</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Facebook className="text-cyan-600 flex-shrink-0 mt-1" size={24} />
                  <div>
                    <p className="font-semibold text-gray-900">Facebook</p>
                    <p className="text-gray-700">Videira_merida</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Clock className="text-cyan-600 flex-shrink-0 mt-1" size={24} />
                  <div>
                    <p className="font-semibold text-gray-900">Horario de Reunión</p>
                    <p className="text-gray-700">Domingos 12:00 PM</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Call to Action */}
        <section className="bg-gradient-to-r from-cyan-600 to-purple-600 text-white rounded-lg p-8 text-center shadow-lg">
          <h2 className="text-3xl font-bold mb-4">¡Únete a Nuestra Comunidad!</h2>
          <p className="text-lg mb-6">
            Te invitamos a ser parte de Videira Mérida y descubre la sincronía perfecta de Dios en tu vida.
          </p>
          <button
            onClick={() => setIsFormOpen(true)}
            className="bg-yellow-400 text-slate-900 px-8 py-3 rounded-lg font-bold hover:bg-yellow-300 transition-colors shadow-md"
          >
            Contáctanos
          </button>
        </section>

        {/* Contact Form Modal */}
        <ContactFormModal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} />
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-8 px-4 mt-16">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-gray-400">
            © 2026 Videira Mérida. Todos los derechos reservados.
          </p>
          <p className="text-xs text-gray-500 mt-2">
            "Ciertamente que la bondad y la misericordia me seguirán todos los días de mi vida; y habitaré en la Casa del Señor para todo el siempre." (Salmo 23:6)
          </p>
        </div>
      </footer>

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fade-in {
          animation: fadeIn 0.6s ease-out;
        }
      `}</style>
    </div>
  );
}
