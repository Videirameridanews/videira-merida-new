# ⚡ Inicio Rápido - Desplegar en Netlify

## 3 Pasos Simples

### 1️⃣ Prepara tu Repositorio en GitHub

```bash
cd videira_news_project
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/TU_USUARIO/videira-merida-news.git
git branch -M main
git push -u origin main
```

### 2️⃣ Conecta a Netlify

1. Ve a [app.netlify.com](https://app.netlify.com)
2. Haz clic en **"Add new site"** → **"Import an existing project"**
3. Selecciona **GitHub** y autoriza
4. Elige el repositorio `videira-merida-news`
5. Deja las configuraciones por defecto (ya están en `netlify.toml`)
6. Haz clic en **"Deploy site"**

### 3️⃣ ¡Listo!

Tu sitio estará en línea en pocos minutos. Netlify te dará una URL como:
```
https://videira-merida-xxxxx.netlify.app
```

## 🔄 Para Actualizar tu Sitio

Solo necesitas hacer push a GitHub:
```bash
git add .
git commit -m "Descripción de cambios"
git push origin main
```

¡Netlify se encargará del resto automáticamente!

## 📖 Para Más Detalles

Lee el archivo `NETLIFY_DEPLOYMENT.md` para una guía completa con:
- Deployment manual con CLI
- Configuración de dominio personalizado
- Solución de problemas
- Variables de entorno
